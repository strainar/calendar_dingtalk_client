"""
HTTP 服务器实现
"""
from fastapi import FastAPI
from .config import get_config
from .caldav.client import CalDAVClient
import uvicorn

config = get_config()
app = FastAPI(title="钉钉 CALDAV 客户端", version="0.1.0")
_caldav_client = None

@app.get("/health")
async def health_check():
    return {"status": "healthy"}

@app.get("/api/calendars")
async def list_calendars():
    if _caldav_client:
        return {"calendars": await _caldav_client.list_calendars()}
    return {"calendars": []}

def main():
    config.validate()
    global _caldav_client
    _caldav_client = CalDAVClient(config.caldav_base_url, config.caldav_username, config.caldav_password)
    uvicorn.run(app, host=config.http_host, port=config.http_port)

if __name__ == "__main__":
    main()
