"""
钉钉 CALDAV 日历客户端
提供 MCP 和 HTTP 服务器访问钉钉 CALDAV 日历
"""
__version__ = "0.1.0"
